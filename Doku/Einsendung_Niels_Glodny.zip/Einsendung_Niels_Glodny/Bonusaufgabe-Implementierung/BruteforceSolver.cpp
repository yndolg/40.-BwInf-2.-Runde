#include "BruteforceSolver.h"

/*
 * Da der BruteforceSolver ein Template ist, befindet sich die Implementation
 * in der Header-Datei.
 */